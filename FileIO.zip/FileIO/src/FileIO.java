import java.io.*;
import java.util.Arrays;

public class FileIO {
    public static void main(String[] args) {
        //array name
        String[] names = {"abdi", "chue", "halima", "rosa"};
        String[] classmates = {"farhan" , "tenzin", "albert", "kong"}; //array for class mates 1
        File CLASSM = new File("classmates.txt");
        try {
            if (CLASSM.createNewFile()) {
                System.out.println("File Created " + CLASSM.getName());
                } else {
                System.out.println("File Already Exists!"); //creation of the classmates.txt file. w3 school
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        } // if nobody got me i know IntelliIJ show context got me. can i get an amen.
        try {
            FileWriter Classwriter = new FileWriter("classmates.txt");
            Classwriter.write("these are the names " + Arrays.toString(classmates)); //intellij sweep
            Classwriter.close();
            System.out.println("Wrote in file"); //write in the classmates.txt file w3 school
        }catch (IOException e) {
            e.printStackTrace();
        }
        BufferedReader bufferedReader;
        try {
            bufferedReader = new BufferedReader(new FileReader("classmates.txt"));
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        String line;
        while (true) {
            try {
                if ((line = bufferedReader.readLine()) == null) break;
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            System.out.println(line);
        }


        //try-catch block
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("output.txt"));
            //write a header
            //slight error idk
            writer.write("Employee Names:/n");
            //loop names
            for (String name : names) {
                writer.write("/n +" + name);
            } //end of loop
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
            //end trycatch
            //display time
        }
        try {
            //Buffered Reader to read a file
            BufferedReader reader = new BufferedReader(new FileReader("output.txt"));
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            } //close
            reader.close();
        }catch (IOException e){
            e.printStackTrace();
        }
    } //end main
}
